export default e =>{
    return({[e.target.name]:e.target.value})
};